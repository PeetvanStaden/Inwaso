#ifndef mainmodbuscontroller_h
#define mainmodbuscontroller_h
#include <Arduino.h>
#include "pins.h"

#include <ModbusRTUMaster.h> 
#include <RS485.h>




 // extern uint16_t holdingRegisters[NUM_HOLDING_REGISTERS];
  
//  extern char SensorsArray[TotalSensors][12];
//  extern bool OutputCtrl[TotalOutputs];    


class mainmodbuscontroller
{
 
  public:
      mainmodbus(uint16_t* _raptorholdingReg,int _sizeofHoldReg);
      bool raptorStart(uint16_t* _raptorholdingReg,int _sizeofHoldReg);
    
      bool modbusSync(uint16_t* holdingReg,bool coils[NUM_COILS],bool outputupdate=false,uint8_t* VFD={0},bool vfdupdate = false);
      bool raptorSync(uint16_t* _raptorholdingReg,int* _outputctrl,int* _outputsatus);
      int convert(int rows,int col,int rowpointer,int colpointer);
      
  private:
    
    int WhosTurn=0;
    void UpdateSlavemA(uint16_t *Buffer,uint16_t* holdingReg);
    void UpdateSlaveInputs(uint16_t *Buffer,uint16_t* holdingReg); 
    uint8_t VFDP[3]={99,99,99};
    unsigned long timestamp=0;   
    int ChangingBit(int Value,int place,bool value);  
      
};
#endif
