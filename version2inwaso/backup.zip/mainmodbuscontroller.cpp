#include "mainmodbuscontroller.h"

    //EthernetClient slave;
    
    ModbusRTUMaster master(RS485);
    
   // bool UpdateTableFromRaptor(char **sensorarray);
   // bool UpdateTableFromEEPROM(char **sensorarray);
 // Ethernet configuration values

  
  // Define the ModbusTCPMaster object
  
    //bool coils[NUM_COILS]={false};
    // Ethernet client object used to connect to the slave
    
    uint32_t lastSentTime = 0UL;
    uint32_t lastSentTimeDiscreteInputs = 0UL;
    uint32_t lastSentTimeOutput = 0UL;   

mainmodbuscontroller::mainmodbus(uint16_t* _raptorholdingReg,int _sizeofHoldReg)
{
 // Serial.begin(115200);
 // Serial.println("Test");
 
// Serial.println(Ethernet.localIP());
 //allocate modbus space for Raptor input

}
bool mainmodbuscontroller::raptorStart(uint16_t* _raptorholdingReg,int _sizeofHoldReg)
{
  RS485.begin(9600UL, HALFDUPLEX, SERIAL_8E1);
  master.begin(9600UL);

}
/*
 * raptorsync step one: Update holding registor from raptors.
 * Check for update thresholds
 * Update Thresholds
 */
bool mainmodbuscontroller::raptorSync(uint16_t* _raptorholdingReg,int* _outputctrl,int* _outputsatus)
{

  //uint16_t holdingRegBackup[600];
  //saving our data that raptor can't edit
  //backup FT001-6
  //
 // Raptorslave.update();
//procure all the sensors raw values
Serial.println();
         //Serial.print("Debugging valve switch before raptorsync-general sensor reading: ");
          //Serial.println(sensorTable[convert(rows,col,XV001R,SensorValue)],DEC);    

 //update switches
         //Serial.print("Debugging valve switch before raptorsync-general level switch reading: ");
          //Serial.println(sensorTable[convert(rows,col,XV001R,SensorValue)],DEC);   

 
 // _raptorholdingReg[ValveStatus] = 0x0000;
         //Serial.print("Debugging valve switch before raptorsync-valve reading: ");
          //Serial.println(sensorTable[convert(rows,col,XV001R,SensorValue)],DEC);    
  //Serial.println("Valves:");

 Serial.print("raw val: ");
 Serial.println(_raptorholdingReg[ValveStatus]);
           //Serial.print("Debugging valve switch after Raptorsync reading: ");
          //Serial.println(sensorTable[convert(rows,col,XV001R,SensorValue)],DEC);    

 //TODO: Extras for feedback -- Not yet possible -need to setup outputstatus (make valves part of output status instead of using sensorTable)
 
//TODO: Pump status unknown -- Write a function that reads the pumps

//TODO: Valve alarms -- Write function to compare output control and output status

//Valve CTRL output
Serial.print("Valve Ctrl value: ");
Serial.println(_raptorholdingReg[ValveControl],DEC);
for(int i = 0; i < 15; i ++)
{
 
  _outputctrl[i] = bitRead(_raptorholdingReg[ValveControl],i);
  Serial.print(_outputctrl[i],DEC);
  Serial.print(" ");
}
Serial.println("--");
//Serial.println(_outputctrl[0],DEC);
//Extra CTL output  --- TODO: impliment the VFDs start and stop functionality
for(int i = 0; i < 11; i ++)
{
  _outputctrl[i+15] =bitRead(_raptorholdingReg[31],i);
  
}
Serial.print(" Motor 1: ");
_outputctrl[PC001]=_raptorholdingReg[199];
Serial.println(_outputctrl[PC001]);
Serial.print(" Motor 2: ");
_outputctrl[PC002]=_raptorholdingReg[33];
Serial.println(_outputctrl[PC002]);
Serial.print(" Motor 4: ");
_outputctrl[PC004]=_raptorholdingReg[34];
Serial.println(_outputctrl[PC004]);


// for (int i = XV001R; i < TotalSensors; i++)
// {
//  int x = i-XV001R;
//  _raptorholdingReg[ValveStatus] = _raptorholdingReg[ValveStatus]|((convert(rows,col,i,sensorTable)&0x0001)<<x);
// }
//
// for(int i = 0;i<TotalThresholdVariables;i++)
//{
//  int x = convert(rows,col,i,HTHRESH);
//  _raptorholdingReg[i+(TotalThresholdVariables*HTHRESH)+ ThresholdOfset]= sensorTable[x];//[i][SensorValue];
//}

//peet - remember to use the outputctrl and outputstatus
 
  return true;
}

bool mainmodbuscontroller::modbusSync(uint16_t* holdingReg,bool coils[NUM_COILS],bool outputupdate=false,uint8_t* VFD={0},bool vfdupdate = false)
{

 // Serial.print(" Whos turn: ");
 // Serial.println(WhosTurn);
  int vfdresponse = 0;
  bool vfdsuccess = false;
  if(millis()>timestamp)
  {
  Serial.print(" Whos turn: ");
  Serial.println(WhosTurn);    
    timestamp=millis()+slaveRefresh;
    switch(WhosTurn){
    case 0:
    if(!master.readInputRegisters(31,0,14))
    {
      // Failure treatment
      Serial.println("Request fail analog read");
    }
    //Serial.println("Requested analog values");
    break;
    case 1:
      if (!master.readDiscreteInputs(31, 0, 14)) {
        // Failure treatment
        Serial.println("Request fail input read");
      }
      //Serial.println("Requested Input values");
    break;
    case 2:
      if (!master.writeMultipleCoils(31, 0, coils,NUM_COILS)) 
      {
        // Failure treatment
        Serial.println("Request fail Output CTRL");
      } 
      //Serial.println("Settingo outputs");
    break;
    case 3:
      for(int i = 0; i< 3;i++)
      {
        Serial.print("VFD: ");
        Serial.print(i,DEC);
        Serial.print(" value:");
        Serial.print(VFD[i]);
        Serial.print(" - ");
        Serial.println(VFDP[i]);
      }
        if(VFD[0]!=VFDP[0])
        {
          Serial.println("Change - pump 1");
          vfdresponse = 0;
           VFDP[vfdresponse]=VFD[vfdresponse];
          unsigned int postvalue = map(VFD[0],0,100,34,70)*327.7;
          Serial.print("Post value for pump 1 = ");
          Serial.println(postvalue);

            //do vfd start command 
            if(VFD[0] ==1)
            {
              if (!master.writeSingleRegister(1, 99, 1151)) 
              {
                // Failure treatment
                  
              }
              else{
                 Serial.println("Request vfd write 1 ON-------------------");               
              }
            }
            else if(VFD[0]==0)
            {
              if (!master.writeSingleRegister(1, 99, 1150)) 
              {
                // Failure treatment
                  
              }
              else{
                 Serial.println("Request vfd write 1 OFF");               
              }              
            }
            Serial.println("Sending speed for pump 1");
          
 

        }
     

        else if(VFD[1]!=VFDP[1])
        {
          Serial.print("Change - pump 2");
          vfdresponse = 1;
          VFDP[vfdresponse]=VFD[vfdresponse];
          unsigned int postvalue = map(VFD[1],0,100,34,70)*327.7;

            //do vfd start command
            if(VFD[1] == 1) 
            {
              if (!master.writeSingleRegister(2, 99, 1151)) 
              {
                // Failure treatment
                  
              }
              else
              {
                Serial.println("  Request vfd write 2 ON");
              }
              
            }
             else if(VFD[0] == 0){
                   
              if (!master.writeSingleRegister(2, 99, 1150)) 
              {
                // Failure treatment
                  
              } 
               Serial.println("Request vfd write 2 OFF");   }                               
       
        }

        else if(VFD[2]!=VFDP[2])
        {
          vfdresponse = 2;
           VFDP[vfdresponse]=VFD[vfdresponse];
          
          Serial.println("Change - pump 4");
            if(VFD[2]==1)
            {
            //do vfd start command 
            if (!master.writeSingleRegister(4, 99,1151)) 
            {
              // Failure treatment
                
            }
            else{
               Serial.println("Request vfd write 4 ON");               
            }
            }else if(VFD[2]==0)
            {
            if (!master.writeSingleRegister(4, 99,1150)) 
            {
              // Failure treatment
                
            }
            else{
               Serial.println("Request vfd write 4 OFF");               
            }              
            }
          
        }
        else
        {
          Serial.println("nothing to change");
          WhosTurn = 0;
        }
     
 


      break;
      default:
      WhosTurn = 0;
      break;
    }
  }


  if(master.isWaitingResponse())
  {
    ModbusResponse response = master.available();

    if(response)
    {
      //Serial.print("Response from wating for response: ");
      //Serial.println(response);
      if(response.hasError())
      {
        Serial.print("Fault message");
      }
      else
      {
        switch (WhosTurn){
        case 0:
          //Serial.println("Input registers:");
          uint16_t TempBuff[NUM_INPUT_REGISTERS];
          for (int i = 0; i < NUM_INPUT_REGISTERS; ++i) 
          {
            TempBuff[i]=response.getRegister(i);
            
            //Serial.print(TempBuff[i]);
           // Serial.print(',');
          }
        //  Serial.println();
          
          //void UpdateSlavemA(char *Buffer,char* sensorTable, int rows, int col)
          //Serial.print("Debugging valve switch before sensor reading: ");
         // Serial.println(sensorTable[convert(sensorRows,sensorCol,XV001R,SensorValue)],DEC);  
         Serial.print(" Before slavema:");
   Serial.println(holdingReg[ValveStatus],DEC);   
          UpdateSlavemA(TempBuff,holdingReg);
             Serial.print("after slavema:");
   Serial.println(holdingReg[ValveStatus],DEC);
          //Serial.print("Debugging valve switch after sensor reading: ");
        //  Serial.println(sensorTable[convert(sensorRows,sensorCol,XV001R,SensorValue)],DEC);
          WhosTurn = 1;
        break;
        case 1:
          uint16_t TempBuff2[NUM_DISCRETE_INPUTS]={0};
       //   Serial.print("Discrete inputs values: ");
          for (int i = 0; i < NUM_DISCRETE_INPUTS; ++i) 
          {
        //    Serial.print(response.isCoilSet(i));
            TempBuff2[i]=response.isCoilSet(i);
        //    Serial.print(',');           
          }
        //  Serial.println();
          //Serial.print("Debugging valve switch before input reading: ");
       //   Serial.println(sensorTable[convert(sensorRows,sensorCol,XV001R,SensorValue)],DEC);
              Serial.print("Before UpdateSlaveInputs:");
   Serial.println(holdingReg[ValveStatus],DEC);
          UpdateSlaveInputs(TempBuff2,holdingReg);
             Serial.print("After UpdateSlaveInputs:");
   Serial.println(holdingReg[ValveStatus],DEC);
          //Serial.print("Debugging valve switch after input reading: ");
        //  Serial.println(sensorTable[convert(sensorRows,sensorCol,XV001R,SensorValue)],DEC);  
          WhosTurn = 0;
        break;
        case 2:
          Serial.println("UPDATING OUTPUTS NOW -----------------");

          Serial.println("Success output control");
          WhosTurn = 0;

        break;
      case 3:

              Serial.println("Success VFD Coms");

            
            VFDP[response]=VFD[response];
          WhosTurn = 0;
      break;   
      default:
      WhosTurn = 0;
      break;        
    
      }
    }
  }
  else
  {


  }
  }
  else
  {
     if(outputupdate == true)
    {
      WhosTurn = 2;
    }
    if(vfdupdate == true)
    {
      WhosTurn = 3;
    }

  }

return true;

//Serial.println("Test");
//  if (!slave.connected()) {
//    slave.stop();
//    slave.connect(slaveIp, slavePort);
//  }
// Send a request every 1000ms if connected to slave


}

      
                           
void mainmodbuscontroller::UpdateSlavemA(uint16_t *Buffer,uint16_t* holdingReg)
{
    float litervalue = 0;
     holdingReg[AT001] = Buffer[0];

//   Serial.println();                                                                     
//   Serial.print("AT001 value:  ");
//   Serial.println(Buffer[0]);
    holdingReg[AT002] = Buffer[1];

//   Serial.println();                                                                     
//   Serial.print("AT002 value:  ");
//   Serial.println(Buffer[1]);
    holdingReg[AT006] = Buffer[2];
 
//   Serial.println();                                                                     
//   Serial.print("AT006 value:  ");
//   Serial.println(Buffer[2]);
 //   holdingReg[AT007] = Buffer[3];TODO: Rearange stuff - fix slave

//   Serial.println();                                                                     
//   Serial.print("AT007 value:  ");
//   Serial.println(Buffer[3]);
    litervalue =Buffer[3] * 2.21788;
    litervalue = litervalue- 509.8581;
    if((litervalue<0)?litervalue=10:litervalue=litervalue);
    holdingReg[LT001] = litervalue;

//   Serial.println();                                                                     
//   Serial.print("LT001 value:  ");
//   Serial.println(Buffer[4]);
    litervalue =Buffer[4] * 2.21788;
    litervalue = litervalue- 509.8581;
    if((litervalue<0)?litervalue=10:litervalue=litervalue);
    holdingReg[LT010] = litervalue;
 //  sensorTable[convert(rows,col,LT010,SensorValue)]=Buffer[4];
   litervalue =Buffer[8] * 2.21788;
   litervalue = litervalue- 509.8581;
   holdingReg[LT013] = litervalue;
  // litervalue = litervalue - 608;
//   sensorTable[convert(rows,col,LT013,SensorValue)]=litervalue;
//     Serial.print("Liter value 1: ");
//   Serial.print(litervalue);
//   Serial.print(" mm");
   litervalue =Buffer[9] * 2.21788;
   litervalue = litervalue- 509.8581;
   holdingReg[LT016] = litervalue;

//   Serial.println();                                                                     
//   Serial.print("LT016 value:  ");
//   Serial.println(Buffer[9]);
    holdingReg[PT001] = Buffer[10];

//   Serial.println();                                                                     
//   Serial.print("PT001 value:  ");
//   Serial.println(Buffer[10]);  
    holdingReg[PT002] = Buffer[11];

//   Serial.println();                                                                     
//   Serial.print("PT002 value:  ");
//   Serial.println(Buffer[11]);
   holdingReg[PT003] = Buffer[12];

//   Serial.println();                                                                     
//   Serial.print("PT003 value:  ");
//   Serial.println(Buffer[12]);
    holdingReg[PT004] = Buffer[13];



}


void mainmodbuscontroller::UpdateSlaveInputs(uint16_t *Buffer,uint16_t* holdingReg)
{

   bitWrite(holdingReg[LevelSwitchesReg],LSLL017,Buffer[0]);
   bitWrite(holdingReg[LevelSwitchesReg],LSH018,Buffer[1]);
   bitWrite(holdingReg[LevelSwitchesReg],LSHH019,Buffer[2]);
   bitWrite(holdingReg[LevelSwitchesReg],LSH020,Buffer[3]);
   if(Buffer[4]>0?Buffer[4]=0:Buffer[4]=1);
   bitWrite(holdingReg[ValveStatus],XV001R,Buffer[4]);
   if(Buffer[11]>0?Buffer[11]=0:Buffer[11]=1);
   bitWrite(holdingReg[ValveStatus],XV002R,Buffer[11]);
   if(Buffer[6]>0?Buffer[6]=0:Buffer[6]=1);
   bitWrite(holdingReg[ValveStatus],XV003R,Buffer[6]);
   if(Buffer[7]>0?Buffer[7]=0:Buffer[7]=1);
   bitWrite(holdingReg[ValveStatus],XV004R,Buffer[7]);
   if(Buffer[8]>0?Buffer[8]=0:Buffer[8]=1);
   bitWrite(holdingReg[ValveStatus],XV009R,Buffer[8]);
   if(Buffer[5]>0?Buffer[5]=0:Buffer[5]=1);
   bitWrite(holdingReg[ValveStatus],XV010R,Buffer[5]);
   if(Buffer[10]>0?Buffer[10]=0:Buffer[10]=1);
   bitWrite(holdingReg[ValveStatus],XV011R,Buffer[10]);
   if(Buffer[9]>0?Buffer[9]=0:Buffer[9]=1);
   bitWrite(holdingReg[ValveStatus],XV012R,Buffer[9]);
   if(Buffer[12]>0?Buffer[12]=0:Buffer[12]=1);
   bitWrite(holdingReg[ValveStatus],XV013R,Buffer[12]);
  Serial.println(holdingReg[ValveStatus],BIN);
   
   /*sensorTable[convert(rows,col,LSLL017,SensorValue)]=Buffer[0];
   sensorTable[convert(rows,col,LSH018,SensorValue)]=Buffer[1];
   sensorTable[convert(rows,col,LSHH019,SensorValue)]=Buffer[2];
   sensorTable[convert(rows,col,LSH020,SensorValue)]=Buffer[3];
   sensorTable[convert(rows,col,XV001R,SensorValue)]=Buffer[4];
//   Serial.print("-----------------------------------");
//   Serial.println(Buffer[4],DEC);
   //Serial.println(sensorTable[convert(rows,col,XV001R,SensorValue)]);
   sensorTable[convert(rows,col,XV002R,SensorValue)]=Buffer[11];
   sensorTable[convert(rows,col,XV003R,SensorValue)]=Buffer[6];
   sensorTable[convert(rows,col,XV004R,SensorValue)]=Buffer[7];
   sensorTable[convert(rows,col,XV009R,SensorValue)]=Buffer[8];
   sensorTable[convert(rows,col,XV010R,SensorValue)]=Buffer[5];
   sensorTable[convert(rows,col,XV011R,SensorValue)]=Buffer[10];
   sensorTable[convert(rows,col,XV012R,SensorValue)]=Buffer[9];
   sensorTable[convert(rows,col,XV013R,SensorValue)]=Buffer[12];*/
   
   //4   
}
int mainmodbuscontroller::ChangingBit(int Value,int place,bool value)
{
  if(value)
  {
    return value |= 1UL << place;
  }
  else
  {
    return value &= ~(1UL << place);
  }
}
int mainmodbuscontroller::convert(int rows,int col,int rowpointer,int colpointer)
{
  int x =  ((rowpointer*col)+colpointer);

  return x;
}                     
