#ifndef outputinputctrl_h
#define outputinputctrl_h
#include <Arduino.h>
#include "pins.h"
#include "mainmodbuscontroller.h"


#define numDigitalInputs int(sizeof(digitalInputsPins) / sizeof digitalInputsPins[0])
#define numAnalogInputs int(sizeof(analogInputsPins) / sizeof analogInputsPins[0])

//extern char SensorsArray[36][9];
   


class outputinputctrl
{
  public:
   // interlock();//char **sensorarray);
   void sensorToOutput(uint16_t* holdingReg);
   void updateHardwareInputs(uint16_t* holdingReg); 
   int updateHardwareOutputs(int OutputCtrl[]);
   int updateHardwareStatus(int OutputStatus[]);
  private:
    int ChangingBit(int Value,int place,bool value);
    mainmodbuscontroller modbus;
    bool SetXV001(int Value);
    bool SetXV002(int Value);
    bool SetXV003(int Value);
    bool SetXV004(int Value);
    bool SetXV009(int Value);
    bool SetXV010(int Value);
    bool SetXV011(int Value);
    bool SetXV012(int Value);
    bool SetXV013(int Value);
    bool SetXV014(int Value);
    bool SetXV015(int Value);
    bool SetXV016(int Value);
    bool SetXV017(int Value);
    bool SetXV018(int Value);
    bool SetXV019(int Value);
    void SetPC003(int Value);
    void SetPC005(int Value);
    void SetPC006(int Value);
    void SetPC007(int Value);
    void SetPC001(int Value);
    void SetPC002(int Value);
    void SetPC004(int Value);    
    void SetMU001(int Value);
    void SetMU002(int Value);
    void SetMU003(int Value);
    bool buff[NUM_COILS]={false};
    uint8_t VFDSpeed[3]={0};
    uint8_t VFDP[3]={99,99,99};

     
};
#endif
